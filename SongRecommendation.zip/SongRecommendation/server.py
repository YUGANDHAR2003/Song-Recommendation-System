from flask import Flask, render_template, request
import pandas as pd
import pickle

app = Flask(__name__)

def recommend_songs(song_title, top_n=5):
    # Load pickled similarity matrices
    with open('similarity_matrix_features.pkl', 'rb') as file:
        similarity_matrix_features = pickle.load(file)

    with open('similarity_matrix_artist.pkl', 'rb') as file:
        similarity_matrix_artist = pickle.load(file)

    with open('similarity_matrix_genre.pkl', 'rb') as file:
        similarity_matrix_genre = pickle.load(file)

    # Load preprocessed data from CSV
    data = pd.read_csv('songs.csv')

    # Find the index of the given song title
    song_index = data[data['title'] == song_title].index[0]

    # Get the similarity scores based on features for the given song
    song_scores_features = similarity_matrix_features[song_index]

    # Get the similarity scores based on artist for the given song
    song_scores_artist = similarity_matrix_artist[song_index]

    # Get the similarity scores based on genre for the given song
    song_scores_genre = similarity_matrix_genre[song_index]

    # Calculate the final similarity scores by combining the scores from different features
    song_scores = 0.4 * song_scores_features + 0.3 * song_scores_artist + 0.3 * song_scores_genre

    # Get the indices of the top similar songs
    top_indices = song_scores.argsort()[-top_n-1:-1][::-1]

    # Get the titles of the top similar songs
    top_songs = data.loc[top_indices, 'title']

    return top_songs

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/recommend', methods=['POST'])
def recommend():
    song_title = request.form['song_title']
    recommended_songs = recommend_songs(song_title, top_n=5)
    return render_template('recommendation.html', song_title=song_title, recommended_songs=recommended_songs)